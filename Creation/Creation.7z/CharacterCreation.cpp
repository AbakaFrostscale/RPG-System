//CharacterCreator.cpp
//CharacterCreator.cpp file that does all the functionality of Building a character
//Author: Kaden Mann
//Description: Portfolio project demonstrating a full RPG system
//version 1.00

#include <string>
#include <algorithm>
#include "CharacterCreator.h"

//Constructor for CharacterCreator to set default values for vectors and CurretnCharacter
FCharacterCreator::FCharacterCreator()
{
	CurrentCharacter = FCharacterData();
	
	
	AvailableRaces = 
	{
		{ERace::ERHuman, FAttributes{1, 1, 1, 1, 1, 1}},
		{ERace::ERElf, FAttributes{0, 1, 0, 0, 2, 0}},
		{ERace::EROrc, FAttributes{2, 0, 1, 0, 0, 0}},
		{ERace::ERDwarf, FAttributes{1, 0, 2, 0, 0, 0}},
		{ERace::ERGnome, FAttributes{0, 1, 0, 2, 0, 0}},
		{ERace::ERTiefling, FAttributes{0, 1, 0, 0, 0, 2}}
		
	};

	AvailableClasses = 
	{
		{EClass::ECFighter, 10 , FAttributes{2, 0, 1, 0, 0, 0}}, 
		{EClass::ECMonk, 8, FAttributes{0, 2, 0, 0, 1, 0}}, 
		{EClass::ECPaladin, 10, FAttributes{1, 0, 0, 0, 0, 2}}, 
		{EClass::ECWizard, 6, FAttributes{0, 0, 1, 2, 0, 0}}, 
		{EClass::ECCleric, 8, FAttributes{1, 0, 0, 0, 2, 0}}, 
		{EClass::ECSorcerer, 6, FAttributes{0, 0, 1, 0, 0, 2}}, 
		{EClass::ECBard, 8, FAttributes{0, 1, 0, 0, 0, 2}}, 
		{EClass::ECDruid, 8, FAttributes{0, 1, 0, 0, 2, 0}}
	};	
}

/** 
Call to Create the character to be used by other classes 
UIName - variable for receiving data from the UI in string format
UIRace/UIClass - variable received from a dropdown or slider for selecting race/class
UISkill - Determines the skill from FAttributes struct that need to be modified using the Mode enum
UIAmount - Determines the amount of AttributesPoints to use with upgrading the skill
*/
void FCharacterCreator::CreateCharacter(std::string UIName, int UIRace, int UIClass, EAttributes UISkill, int UIAmount, EIncreaseOrDecrease Mode)
{
	CurrentCharacter.CharName = UIName;

	ChooseRace(UIRace);
	ChooseClass(UIClass);
	
	CurrentCharacter.CharStats = CurrentCharacter.BaseStats;

	AllocateAttributePoints(UISkill, UIAmount, Mode);

	FinalizeCharacter();	
}

//Chooses the race from AvailableRaces based on an index fed in from the UI
void FCharacterCreator::ChooseRace(int RaceIndex)
{	
	if(bIsFinalised) { return; }	

	if (RaceIndex < 0 || RaceIndex >= AvailableRaces.size())
	return;
	
	CurrentCharacter.CharRace = AvailableRaces[RaceIndex].Race;
	ApplyRaceBaseStats();
}

//Chooses the class from AvailableClasses based on an index fed from the UI
void FCharacterCreator::ChooseClass(int ClassIndex)
{
	if (bIsFinalised) { return; }

	if (ClassIndex < 0 || ClassIndex >= AvailableClasses.size())
	return;
	
	CurrentCharacter.CharClass = AvailableClasses[ClassIndex].Class;
	ApplyClassModifiers();
}

/**
Current, checks the CurrentCharacters stat that need to be increased
Base, is used to compare the stat to the minimum amount to avoid dropping a stat too low (Base = Race.Stat + Class.Stat)
Amount is the value that a stat should be increased by which also deducts from AvailableAttributePoints
Mode determines whether a stat should be increased or decreases

Assumes Amount has been validatd by the caller
*/
bool FCharacterCreator::TryAllocatePoints(int& Current, int Base, int Amount, EIncreaseOrDecrease Mode)
{
	if (Mode == EIncreaseOrDecrease::EIIncrease)
			{ 
				Current += Amount;
				return true;	
			} 
			else if (Mode == EIncreaseOrDecrease::EIDecrease 
					&& (Current - Amount) >= Base)
			{
				Current -= Amount;
				return true;
			}
	return false;
}

/**
Skill refers the the CurrentCharacter.CharStat that needs to be increased
Amount is the values that a stat should be increased by which also deducts from AvailableAttributePoints
Mode determines whether the Skill should be increased or decreased, this will be fed in from the UI
*/

void FCharacterCreator::AllocateAttributePoints(EAttributes Skill, int Amount, EIncreaseOrDecrease Mode) 
{ 
	if (bIsFinalised) { return; }
	if (AvailableAttributePoints <= 0 && Mode == EIncreaseOrDecrease::EIIncrease) return;
		
	AvailableAttributePoints = std::min(AvailableAttributePoints, MaxAttributePoints);
	bool bStatChanged = false;

	if (Mode == EIncreaseOrDecrease::EIIncrease)
	{
		Amount = std::clamp(Amount, 0, AvailableAttributePoints);
	}
	else if (Mode == EIncreaseOrDecrease::EIDecrease)
	{
		Amount = std::clamp(Amount, 0, MaxAttributePoints);
	}


	switch (Skill) 
	{	 
		case EAttributes::EStr :
			bStatChanged = TryAllocatePoints(
					CurrentCharacter.CharStats.Str,
					CurrentCharacter.BaseStats.Str,
					Amount,
					Mode);
			break;
			
		case EAttributes::EDex :
			bStatChanged = TryAllocatePoints(
					CurrentCharacter.CharStats.Dex,
					CurrentCharacter.BaseStats.Dex,
					Amount,
					Mode);
			break;

		case EAttributes::ECon : 
			bStatChanged = TryAllocatePoints(
					CurrentCharacter.CharStats.Con,
					CurrentCharacter.BaseStats.Con,
					Amount,
					Mode);
			break;

		case EAttributes::EInt :
			bStatChanged = TryAllocatePoints(
					CurrentCharacter.CharStats.Int,
					CurrentCharacter.BaseStats.Int,
					Amount,
					Mode);
			break;

		case EAttributes::EWis : 
			bStatChanged = TryAllocatePoints(
					CurrentCharacter.CharStats.Wis,
					CurrentCharacter.BaseStats.Wis,
					Amount,
					Mode);
			break;

		case EAttributes::ECha :
			bStatChanged = TryAllocatePoints(
					CurrentCharacter.CharStats.Cha,
					CurrentCharacter.BaseStats.Cha,
					Amount,
					Mode);
			break;

		default : 
			break; 
	}
	if (Mode == EIncreaseOrDecrease::EIIncrease && bStatChanged)
	{ 
		AvailableAttributePoints -= Amount; 		
	} 
	else if (Mode == EIncreaseOrDecrease::EIDecrease && bStatChanged)
	{
		AvailableAttributePoints += Amount; 
	}
	
}

//Applies the stats of Race to the CurrentCharacter
void FCharacterCreator::ApplyRaceBaseStats()
{
	for (FRaceData& RaceData : AvailableRaces)
	{
		if (CurrentCharacter.CharRace == RaceData.Race)
		{
			CurrentCharacter.CharStats.Str = RaceData.BaseStat.Str;
			CurrentCharacter.CharStats.Dex = RaceData.BaseStat.Dex;
			CurrentCharacter.CharStats.Con = RaceData.BaseStat.Con;
			CurrentCharacter.CharStats.Int = RaceData.BaseStat.Int;
			CurrentCharacter.CharStats.Wis = RaceData.BaseStat.Wis;
			CurrentCharacter.CharStats.Cha = RaceData.BaseStat.Cha;
		}
	}
}

//Adds the Class Stat modifiers to the Current Character
void FCharacterCreator::ApplyClassModifiers()
{
	for (FClassData& ClassData : AvailableClasses)
	{
		if (CurrentCharacter.CharClass == ClassData.Class)
		{
			CurrentCharacter.CharStats.Str += ClassData.StatModifier.Str;
			CurrentCharacter.CharStats.Dex += ClassData.StatModifier.Dex;
			CurrentCharacter.CharStats.Con += ClassData.StatModifier.Con;
			CurrentCharacter.CharStats.Int += ClassData.StatModifier.Int;
			CurrentCharacter.CharStats.Wis += ClassData.StatModifier.Wis;
			CurrentCharacter.CharStats.Cha += ClassData.StatModifier.Cha;
		}
	}
}

void FCharacterCreator::SetCharacterHP()
{
	for (FClassData& ClassData :AvailableClasses)
	{
		if (CurrentCharacter.CharClass == ClassData.Class)
		{
			CurrentCharacter.MaxHP = ClassData.BaseHealth + CurrentCharacter.CharStats.Con;
		}
	}

	CurrentCharacter.CurrentHP = CurrentCharacter.MaxHP;		
}

//Sets the character MP based on class, according to the ability they use to cast spells
void FCharacterCreator::SetCharacterMP()
{
	switch (CurrentCharacter.CharClass)
	{
		case EClass::ECWizard : 
			CurrentCharacter.MaxMP = CurrentCharacter.CharStats.Int * 2;
			break;
		case EClass::ECPaladin :
			CurrentCharacter.MaxMP = CurrentCharacter.CharStats.Cha * 2;
			break;
		case EClass::ECCleric :
			CurrentCharacter.MaxMP = CurrentCharacter.CharStats.Wis * 2;
			break;
		case EClass::ECSorcerer :
			CurrentCharacter.MaxMP = CurrentCharacter.CharStats.Cha * 2;
			break;
		case EClass::ECBard :
			CurrentCharacter.MaxMP = CurrentCharacter.CharStats.Cha * 2;
			break;
		case EClass::ECDruid : 	
			CurrentCharacter.MaxMP = CurrentCharacter.CharStats.Wis * 2;
			break;
		default :
			CurrentCharacter.MaxMP = 0;		
	}

	CurrentCharacter.CurrentMP = CurrentCharacter.MaxMP;

}

//Changes ERace to string for any form of printing to console (redundant, but for debugging)
std::string FCharacterCreator::ERaceToString(ERace Race) const
{
	switch (Race)
	{
		case ERace::ERHuman : return "Human";
		case ERace::ERElf : return "Elf";
		case ERace::EROrc : return "Orc";
		case ERace::ERDwarf : return "Dwarf";
		case ERace::ERGnome : return "Gnome";
		case ERace::ERTiefling : return "Tiefling";
		default : return "No Race Selected!";
	}
}

//Changes EClass to string for any form of printing to console (redundant, but for debugging)
std::string FCharacterCreator::EClassToString(EClass Class) const
{
	switch (Class)
	{
		case EClass::ECFighter : return "Fighter";
		case EClass::ECMonk : return "Monk";
		case EClass::ECPaladin : return "Paladin";
		case EClass::ECWizard : return "Wizard";
		case EClass::ECCleric : return "Cleric";
		case EClass::ECSorcerer : return "Sorcerer";
		case EClass::ECBard : return "Bard";
		case EClass::ECDruid : return "Druid";
		default : return "No Class Selected!";
	}
}

bool FCharacterCreator::IsCharacterValid() const
{
	if (CurrentCharacter.CharName.empty()) {return false; }

	if (AvailableAttributePoints != 0) { return  false; }

	return true;
}

bool FCharacterCreator::FinalizeCharacter()
{
	if (!IsCharacterValid()) { return false; }

	SetCharacterHP();
	SetCharacterMP();

	bIsFinalised = true;
	return true;
}





