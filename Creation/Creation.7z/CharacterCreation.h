//CharacterCreator.h
//CharacterCreator.h file hold all the information for CharacterCreator.cpp to build a character
//Author: Kaden Mann
//Description: Portfolio project demonstrating a full RPG system
//version 1.00

#pragma once

#include <string>
#include <vector>
#include "Core/Types.h"
#include "Character/CharacterStats.h"

enum class EAttributes { EStr, EDex, ECon, EInt, EWis, ECha };

enum class EIncreaseOrDecrease { EIIncrease, EIDecrease };

class FCharacterCreator
{
public:
	FCharacterCreator();
	void CreateCharacter(std::string UIName, int UIRace, int UIClass, EAttributes UISkill, int UIAmount, EIncreaseOrDecrease Mode);

private:
	void ChooseRace(int RaceIndex);
	void ChooseClass(int ClassIndex);

	void AllocateAttributePoints(EAttributes Skill, int Amount, EIncreaseOrDecrease Mode);
	void ApplyRaceBaseStats();
	void ApplyClassModifiers();

	void SetCharacterHP();
	void SetCharacterMP();

	bool TryAllocatePoints(int& Current, int Base, int Amount, EIncreaseOrDecrease Mode);

	std::string ERaceToString(ERace Race) const;
	std::string EClassToString(EClass Class) const;

	bool IsCharacterValid() const;
	bool FinalizeCharacter();

private:
	FCharacterData CurrentCharacter;
	std::vector<FRaceData> AvailableRaces;
	std::vector<FClassData> AvailableClasses;

	int AvailableAttributePoints = 10;
	int MaxAttributePoints = 10;
	
	bool bIsFinalised;
};

